﻿using Meep.Tech.Data;

namespace $rootnamespace$ {

  public class $fileinputname$ : Enumeration<$fileinputname$> {

    public static $fileinputname$ $fileinputname$Item {get;}
      = new $fileinputname$(nameof($fileinputname$Item));

    protected $fileinputname$(string uniqueNameFor$fileinputname$) 
      : base(uniqueNameFor$fileinputname$) { } 

  }
}